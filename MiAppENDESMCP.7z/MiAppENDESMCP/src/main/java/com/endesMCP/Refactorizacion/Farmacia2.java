package com.endesMCP.Refactorizacion;

import java.util.HashMap;
import java.util.Map;


public class Farmacia2 {
    /**
     * crea un inventario que es un mapa donde iran los medicamentos
     */
        public Map<String, Integer> inventario;

        public Farmacia2() {
            this.inventario = new HashMap<>();
        }
    }
