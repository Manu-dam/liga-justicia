package com.endesMCP.Refactorizacion;

import com.endesMCP.Refactorizacion.Farmacia2;
import com.endesMCP.Refactorizacion.MedicamentoGenerico;
import com.endesMCP.Refactorizacion.MedicamentosEspecializados;

import java.util.Map;
import java.util.Random;

public class Principal {
    /**
     * Esta clase se encargara de imprimir los metodos de calcular el precio del medicamento en funcion del que sea
     * @param args
     */
    public void main(String[] args) {
        Farmacia2 farmacia = new  Farmacia2();
        Random random = new Random();

        MedicamentoGenerico paracetamol = new MedicamentoGenerico("Paracetamol", 10.0);
        paracetamol.agregarAlInventario(farmacia, 100);

        String nombre1 = "Medicamento1";
        double precio1 = random.nextDouble() * 100;
        MedicamentoGenerico medicamentoGenerico1 = new MedicamentoGenerico(nombre1, precio1);
        medicamentoGenerico1.agregarAlInventario(farmacia, 100);


         MedicamentosEspecializados insulina = new MedicamentosEspecializados("Insulina", 50.0, "Diabetes");
        insulina.agregarAlInventario(farmacia, 20);


        System.out.println("Inventario de la farmacia:");
        for (Map.Entry<String, Integer> entry :farmacia.inventario.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue() + " unidades");
        }
    }
}
