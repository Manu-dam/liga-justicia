package com.endesMCP.Refactorizacion;

import com.endesMCP.Refactorizacion.Farmacia2;
import com.endesMCP.Refactorizacion.Medicamento;

public class MedicamentoGenerico extends Medicamento {
    /**
     * se encaraga de los medicamentos normales es hija de medicamento y los agrega al inventario si existen o no y si ya existe solo le suma  el numeor de medicamnetos que entran a la cantidad
     * @param nombre
     * @param precio
     */
    public MedicamentoGenerico(String nombre, double precio) {
        super(nombre, precio);
    }

    @Override
    public void agregarAlInventario(Farmacia2 farmacia, int cantidad) {
        String nombre = super.getNombre();
        if (farmacia.inventario.containsKey(nombre)) {
            int cantidadExistente = farmacia.inventario.get(nombre);
            farmacia.inventario.put(nombre, cantidadExistente + cantidad);
        } else {
            farmacia.inventario.put(nombre, cantidad);
        }
    }
}
