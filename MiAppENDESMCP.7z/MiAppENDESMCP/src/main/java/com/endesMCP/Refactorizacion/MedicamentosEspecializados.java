package com.endesMCP.Refactorizacion;

import com.endesMCP.Refactorizacion.Farmacia2;
import com.endesMCP.Refactorizacion.Medicamento;

public class MedicamentosEspecializados extends Medicamento {
    /**
     * Clase hija de medicamneto  se encarga de controlar los tipos de medicamentos y añadirlos al inventario si existen o no y si ya existe solo le suma  el numeor de medicamnetos que entran a la cantidad
     */
    private String tipo;

    public MedicamentosEspecializados(String nombre, double precio, String tipo) {
        super(nombre, precio);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    @Override
    public void agregarAlInventario(Farmacia2 farmacia, int cantidad) {
        String nombre = super.getNombre();
        if (farmacia.inventario.containsKey(nombre)) {
            int cantidadExistente = farmacia.inventario.get(nombre);
            farmacia.inventario.put(nombre, cantidadExistente + cantidad);
        } else {
            farmacia.inventario.put(nombre, cantidad);
        }
    }
}
