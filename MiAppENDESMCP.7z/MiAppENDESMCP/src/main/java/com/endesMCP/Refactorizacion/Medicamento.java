package com.endesMCP.Refactorizacion;

import com.endesMCP.Refactorizacion.Farmacia2;

/**
 * clase clase padre medicamneto tiene toda la informacion de un medicamento nombre y precio y el metodo agragar al inventariop que agrega medicamentos al inventario
 */
public abstract class Medicamento {
        public String nombre;
        public double precio;

        public Medicamento(String nombre, double precio) {
            this.nombre = nombre;
            this.precio = precio;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public double getPrecio() {
            return precio;
        }

        public void setPrecio(double precio) {
            this.precio = precio;
        }


        public abstract void agregarAlInventario(Farmacia2 farmacia, int cantidad);
    }

