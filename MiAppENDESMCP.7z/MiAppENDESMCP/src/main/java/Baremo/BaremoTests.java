package Baremo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BaremoTests {

	@Test
	void testBaremo() {
		assertEquals("Adjudica", Baremo.comporbarBaremo("1234567A", 9));
		assertEquals("Adjudica", Baremo.comporbarBaremo("1283367A", 6));
		assertEquals("No Adjudica", Baremo.comporbarBaremo("1234567A", 4));
		assertEquals("No Adjudica", Baremo.comporbarBaremo("1234567A", 2));
		}

}
