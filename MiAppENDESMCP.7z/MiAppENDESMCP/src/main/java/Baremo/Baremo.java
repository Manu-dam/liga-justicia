package Baremo;

public class Baremo {
	
	
	public static String comporbarBaremo(String DNI, int baremo) {
		if(baremo > 5) 
			return "Adjudica";
		else  
			return "No Adjudica";
		
	}
	
}
