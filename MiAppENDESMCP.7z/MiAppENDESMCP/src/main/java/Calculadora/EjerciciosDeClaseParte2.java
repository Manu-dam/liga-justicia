package Calculadora;

import static org.junit.jupiter.api.Assertions.*;

import EjerciciosClase.MisArrays;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer.Alphanumeric;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

class EjerciciosDeClaseParte2 {
	@Disabled
	@Test
	void testSuma() {
		MisArrays arra = new MisArrays();
		int[] array1 = new int[] { 2, 4, 5};
		int[] array2 = new int[] { 1, 1, 1};
		int[] resul = new int[] { 3, 5, 6};
		assertArrayEquals(resul, arra.sumar(array1, array2));
	}
static int[]a1, a2, resul2, array1, array2, resul, array3, array5, array6, resul3;

	
	@BeforeAll
	static void iniciar() {
		a1 = new int[]{2,4,5};
		a2 = new int[]{1,1,1};
		resul2  = new int[]{3,5,6};
		array1 = new int[]{4, 3, 2, 5, 6};
		array2 = new int[]{1, 1, 1, 3, 6};
		resul  = new int[]{5, 4, 3, 8, 12};
		array3 = new int[] {2,4,5};
	}
	@Test
	void testSuma2() {
		MisArrays arra1 = new MisArrays();
		assertArrayEquals(resul, arra1.sumar(array1, array2));
	}
	@Test
	void testSumar() {
		MisArrays arra = new MisArrays();
		assertArrayEquals(resul2, arra.sumar(a1, a2));
	}
	@Test
	void testDecrementar1() {
		MisArrays arra = new MisArrays();
		arra.decrementar(array3, 1);
		assertArrayEquals(array3, new int[] {1,3,4});
	}
	@BeforeEach
	void iniciar2() {
		array5 = new int[]{2,4,5};
		array6 = new int[]{1,1,1};
		resul3 = new int[]{3,5,6};
	}
	
	@AfterAll
	void fin() {
		System.out.println("Fin de los test");
	}
	
	@AfterEach
	void finalizar2() {
		System.out.println("Fin de un test");
	}
	
}
