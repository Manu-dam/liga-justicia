package Calculadora;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class calculadoraTest {

	@Test
	void testRestar() {
		//fail("Not yet implemented");
		assertEquals(5,calculadora.restar(10, 5));	
		assertEquals(1,calculadora.restar(6, 5));
		assertEquals(6,calculadora.restar(8, 2));
	}
	@Test
	void testRestar1() {
		assertEquals(5,calculadora.restar(10, 5));
	}
	@Test
	void testRestar2() {
		assertEquals(1,calculadora.restar(6, 5));
	}
	@Test
	void testRestar3() {
		assertEquals(6,calculadora.restar(8, 2));
	}
	@Test
	void testDividir1() {
		assertEquals(1,calculadora.dividir(4, 4));
	}
	@Test
	void testDividir() {
		assertEquals(1,calculadora.dividir(3, 2));
	}
	@Test
	void testDividir3() {
		assertThrows(ArithmeticException.class,()->calculadora.dividir(4, 0));

	}
	@Test
	void testDividirVarios() {
	assertAll("Juntado Test",
			()->assertEquals(1, calculadora.dividir(4, 4)),
			()->assertEquals(1, calculadora.dividir(3, 2))
			);
	}
	@Test
	void testDividirTrue() {
	assertTrue(calculadora.dividir(6, 2)==3);
	}
	@Test
	void testPar() {
     assertTrue(calculadora.esPar(2));
     assertTrue(calculadora.esPar(3));
	}
	@Test
	void testPar2() {
	     calculadora.esParTexto(0);
	     calculadora.esParTexto(25);
	     
	     //calculadora.esParTexto("Hola");
	   //calculadora.esParTexto(3.5);
		}
	
	@Test
	void testComprobar() {
		assertEquals("Par",calculadora.esParTexto(2));
	}
	

	

}
