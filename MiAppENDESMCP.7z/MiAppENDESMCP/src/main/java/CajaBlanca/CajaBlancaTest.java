package CajaBlanca;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CajaBlancaTest {



	@Test
	public void ejercicio2() {
		assertEquals(-1, CajaBlanca.ejercicio2(-1, 3, 4));
		assertEquals(-1, CajaBlanca.ejercicio2(2, 3, 5));
		assertEquals(1, CajaBlanca.ejercicio2(2, 6, 1));
	}
	
	@Test
	public void ejercicio3() {
		assertEquals(4, CajaBlanca.ejercicio3(-1, 3, 4));
		assertEquals(5, CajaBlanca.ejercicio3(2, 3, 5));
		assertEquals(6, CajaBlanca.ejercicio3(2, 6, 1));
	}
	
	    @Test
	    public void ejercicio4() {
	        char[] cadena = {'a', 'o', 'g', 'f'};
	        char letra = 'o';
	        int expected = 1;
	        int actual = CajaBlanca.ejercicio4(cadena, letra);
	        assertEquals(expected, actual);
	        
	        
	        char[] cadena2 = {'t', 'a', 'r', 'v', 'o'};
	        char letra2 = 'o';
	        int expected2 = 1;
	        int actual2 = CajaBlanca.ejercicio4(cadena2, letra2);
	        assertEquals(expected2, actual2);
	        
	        
	        
	        char[] cadena3 = {};
	        char letra3 = 'o';
	        int expected3 = 0;
	        int actual3 = CajaBlanca.ejercicio4(cadena3, letra3);
	        assertEquals(expected3, actual3);
	    }


}
