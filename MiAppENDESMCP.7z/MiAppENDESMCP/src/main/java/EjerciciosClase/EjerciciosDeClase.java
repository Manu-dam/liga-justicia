package EjerciciosClase;

import static org.junit.jupiter.api.Assertions.*;

import Calculadora.calculadora;
import org.junit.jupiter.api.Test;

class EjerciciosDeClase {

	@Test
	void testRestar1() {
		assertEquals(2, calculadora.restar(4, 2)); // originalmente seria un dos y 2,4
	}
	@Test
	void testRestar2() {
		assertEquals(0,calculadora.restar(6, 6));
	}
	@Test
	void testRestar3() {
		assertEquals(3,calculadora.restar(5, 2)); // original mente noe ra un 3 sino un 5
	}
	
	
	
	@Test
	void testDividir1() {
		assertTrue(calculadora.dividir(4, 4)==1);
	}
	@Test
	void testDividir2() {
		assertTrue(calculadora.dividir(3, 2)==1);
	}
	@Test
	void testDividir3() {
		assertThrows(ArithmeticException.class,()->calculadora.dividir(4,0));
	}
	
	
	@Test
	void testDividir4() {
		assertAll("JuntandoTest", 
				()->assertEquals(1, calculadora.dividir(4,4)),
				()->assertEquals(1, calculadora.dividir(3,2))
				);
	}
	
	
	
	
	
	@Test
	void testDividir5() {
		assertTrue(calculadora.dividir(6, 2)== 3);
	}
	
	
	@Test
	void testesPar() {
		assertTrue(calculadora.esPar(2)== true);
	}
	@Test
	void testesImpar() {
		assertFalse(calculadora.esPar(2)== false);
	}
	@Test
	void testesEsParOImpar() {
		assertAll("JuntandoTest2", 
				()->assertEquals("Par", calculadora.esParTexto(0) ),
				()->assertEquals("Impar", calculadora.
						esParTexto(25))
				);
	}
	

	
	
	
	
}
