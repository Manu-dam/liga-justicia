package EjerciciosClase;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.junit.jupiter.api.Test;

public class MisArrays {

	public  int[] sumar(int[] array1, int[] array2) {
		if(array1.length != array2.length)
			return null;
		int[]salida = new int[array1.length];
		for(int i = 0; i < array1.length; i++) {
		salida[i] = array1[i]+array2[i];
		}
		return salida;
			
		}
	public void decrementar(int[] arra, int num) {
		for(int i = 0; i < arra.length; i++) {
			arra[i] = arra[i]-num;
		}
	}
	}
